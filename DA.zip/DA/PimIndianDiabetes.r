library(caTools)
library(e1071)
mydata <-read.csv(file = "~/r_data/diabetes.csv", header = TRUE, sep =",")
View(mydata)
str(mydata)
temp_field <- sample.split(mydata, SplitRatio = 0.7)
train <- subset(mydata, temp_field == TRUE)
test <- subset(mydata, temp_field == FALSE)
View(train)
View(test)
head(train)
head(test)
my_model <- naiveBayes(as.factor(train$Outcome) ~ ., train)
my_model
#predicting, try putting type="class" or type="raw"after test
pred1 <- predict(my_model, test[, -9])
pred1
table(pred1, test$Outcome, dnn = c("predicted", "Actual"))
output <- cbind(test, pred1)
View(output)

